#1 Generate 3 random integers between 100 and 999 which is divisible by 5

import random
print("1 st ans:")
for num in range(3):
    print(random.randrange(100, 999, 10))