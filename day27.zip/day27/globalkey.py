import random
x=1
y=2

def  function1(x):
	#global y
	
	#x=globals()['x']+x
	
	print(x)

function1(50)


ran=['a','b','c','d','e']
ran1=random.choice(ran)
string='dipak'
change=''
for i in string:
	if i =='d':
		i=ran1
	change += i
print(change)


string='dipak kavade'
abc=string.split()
change=''
for i in abc:
	if i =='kavade':
		i=' bhai'
	change += i
print(change)



'''
def f(s):
    #global s
    s += ' GFG'
    print(s)
    s = "Look for Geeksforgeeks Python Section"
    print(s)
 
# Global Scope
s = "Python is great!"
f('hello')
print(s)'''