def student3():
	
	stu=('dipak','sagar','kajal','nima')
	print("student of standard 3")

	for i in stu:
		print(i);