

def student1():

	stu=('dipak','sagar','kajal','nima')
	print("student of standar 1")
	for i in stu:
		print(i);