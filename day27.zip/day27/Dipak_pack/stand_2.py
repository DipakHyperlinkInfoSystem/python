def student2():

	
	stu=('manali','jimit','karan','chetan')
	print("student of standard 2")
	for i in stu:
		
		print(i,end="/");