import mudule

mudule.myModule(10,20)