#1 Generate 3 random integers between 100 and 999 which is divisible by 5

import random
print("1 st ans:")
for num in range(3):
    print(random.randrange(100, 999, 10))

#2 Random Lottery Pick. Generate 100 random lottery tickets and pick two lucky tickets from it as a winner.

lis=[]
for ticket in range(100):
    lis.append(random.randrange(100))
win=random.sample(lis,2)
print("2n ans:",win)

#3 Generate 6 digit random secure OTP

import random

otp = random.randrange(10000, 20000);

print("3rd ans otp:", otp);

#4
import random
st="hello"
char = random.choice(st)
print("")
print("4th ans : random char:", char);

#5 Generate random String of length 5

string="hellowordlhyper"

for i in range(5):
    char5=random.choice(string)
print("5 ans:"+char5,end='')


#6 Calculate multiplication of two random float numbers

numer=[]

for num in range(2):
    h = random.uniform(20, 60)
    numer.append(h)
print("6 ans:")
print(numer)
print("7th ans:",numer[0]+numer[1])

#7 Generate random secure token of 64 bytes and random URL

import secrets
toke= secrets.token_bytes(64)
print("8th ans:",toke)


#9 Roll dice in such a way that every time you get the same number
dice=[1,2,3,4,5,6]
for i in range(1):
    random.seed(1)
    print("9th ans: dice print",random.choice(dice))

#10 Generate a random date between given start and end dates
inputS = "pythoninhlink"

a=int(len(inputS)/2)
newString = inputS[ 0:1 ] + inputS[a] +inputS [-2:]

# Printing the new String
print("Input string = " + inputS)
print("New String = "+ newString)


