# break keywork examples

my_list = ['dipak', 'jay', 'parin', 'manali', 'kajal', 'dhisu'] 

for i in range(len(my_list)):
    print(my_list[i])
    if my_list[i] == 'jay':
        print('Found the name parin')
        break
        print('After break statement')

print('Loop is Terminated')

output: 
dipak
jay
parin
Found the name parin
After break statement



# continue keyword example 

for i in range(5):    
    if i == 3:
        continue  
    print("The Number is :" , i)

output:
The Number is : 0
The Number is : 1
The Number is : 2
The Number is : 4
The Number is : 5


#pass keyword example

def my_func():
    print('pass inside function')
    pass
my_func()

output:
pass inside function


#while with continue and nested if

while i <= 10:
    if i == 7:
        if i == 7:
            print("we got 7 in nested loop")
        i += 1
        continue
    print("The Number is  :" , i)
    i += 1
    print("loop if ")
print("loop terminet")


output:
The Number is  : 0
loop if 
The Number is  : 1
loop if 
The Number is  : 2
loop if 
The Number is  : 3
loop if 
The Number is  : 4
loop if 
The Number is  : 5
loop if 
The Number is  : 6
loop if 
The Number is  : 8
loop if 
The Number is  : 9
loop if 
The Number is  : 10
loop if 
loop terminet

#function 

def check():
    print("dipak")

    def my_func():
        print('pass inside function')
    my_func()

check()

output:
dipak
pass inside function


# function with argument 

def sum(num):
    x=num+5
    if x > 10:
        print("x is freter than 10")
    else:
        print("x less than 10")

sum(10)

output:

x is freter than 10


def fibonaci(n):
    if n <= 1:
        return n
    else:
        return (fibonaci(n-1) +  fibonaci(n-2))
10
num = int(input("enter the number"))

if num <=0:
    print("please enter greter than 0 ")

else:
    print("fibonaci serise")
    for i in range(num):
        print(fibonaci(i))


output:
0
1
1
2
3
5
8
13
21
34

#global variable
x = "global"

def foo():
    print("x inside:", x)


foo()
print("x outside:", x)

output:

x inside: global
x outside: global


#local variable

def foo():
    y = "local"
    print(y)


foo()
print(y)

output:
local
NameError: name 'y' is not defined


#nonlocal

def outer():
    x = "local"

    def inner():
        nonlocal x
        x = "nonlocal"
        print("inner:", x)

    inner()
    print("outer:", x)


outer()

output:
inner: nonlocal
outer: nonlocal


#lambda

x = lambda a, b: a * b
print(x(10, 20))














