#1 Create a string made of the first, middle and last character
inputS = "pythoninhlink"

a=int(len(inputS)/2)
newString = inputS[ 0:1 ] + inputS[a] +inputS [-2:]

# Printing the new String
print("Input string = " + inputS)
print("1st ans :New String = "+ newString)

#2- Create a string made of the middle three characters
st='JhonDipPeta'
st1='JaSonAy'

a=int(len(st)/2)
b=int(len(st1)/2)

newString1= st[a-1] + st[a] + st[a+1]
newString2= st1[b-1] + st1[b] + st1[b+1]
print("2nd ans:",newString1,newString2)

#3 Append new string in the middle of a given string

q3="flowers is inworld"
addstring=" beutifull "

temp = q3.split()
mid_pos = len(temp) // 2

newString=temp[:mid_pos] + [addstring] + temp[mid_pos:]

newString= ''.join(newString)

print("3rs ans:",newString)

#4Create a new string made of the first, middle, and last characters of each input string

q4="helloworld"
add="howareyou"

fir=q4[0]+add[0]

m_pos1=int(len(q4)/2)
m_pos2=int(len(add)/2)

middd=q4[m_pos1]+add[m_pos2]

last1=len(q4)-1
last2=len(add)-1

end=q4[last1]+add[last2]

print("4th ans :",fir+middd+end)

#5 Arrange string characters such that lowercase letters should come first

q5="hDjdjdjJDKDKK"
l=[]
u=[]
for c in q5:
    if c.islower():
        l.append(c)

    if c.isupper():
        u.append(c)


rsult=''.join(l+u)

print(rsult)

#6 Count all letters, digits, and special symbols from a given string

q6="hdfkj65243@#$$"
special="@#$%^&*()_{[}]+-"
num=[]
spe=[]
cha=[]
for c in q6:
    if c.isdigit():
        num.append(c)
    if c.isalpha():
        cha.append(c)
    if c in special:
        spe.append(c)
print("6th ans:")
print("digit count :",len(num))
print("char count :",len(cha))
print("special char count :",len(spe))

#7 Create a mixed String using the following rules

#8 String characters balance Test

s1="abc"
s2="abv"
ans="present"
for i in s1:
    if i in s2:
        continue
    else:
        ans="not present"
print("8th ans :",ans)


#9Find all occurrences of a substring in a given string by ignoring the case

q9="Welcome to INDIA. in india awesome, isn't it?"
sub="india"
q9=q9.lower()
ans=q9.count(sub)
print(ans)
#10Calculate the sum and average of the digits present in a string

q10="PYnative29@#8496"
result=0
num=[]
for i in q10:
    if i.isdigit():
        result=+int(i)
        num.append(int(i))

ans=sum(num)
print("10th ans sum:",ans,"avrg")
from collections import Counter
#11 Write a program to count occurrences of all characters within a string

q11="hello every one how are you i hope you all are well and good"

coun=Counter(q11)
print("11th ans:")
print(coun)
print("max printed:"+ str(coun.get(" ")))

#12 Reverse a given string

q12="hello world"

reve=q12[::-1]
print("12th ans::",reve)

#13 Find the last position of a given substring

q13="John is a data scientist who knows Python. John works at google."

ans=q13.rindex("John")# return exception if not found
ans1=q13.rfind("john") #return -1 if not found
print("13th ans:")
print(ans)
print(ans1)

#14 Split a string on hyphens

q15="John-is-a-data-scientist"
final=[]
print("14th ans:")
for i in q15:
    if i!='-':
        final.append(i)
        print(i,end='')
ansa=q15.split('-')

for i in ansa:
    print(i)

#15 Remove empty strings from a list of strings
str_list = ["Emma", "Jon", "", "Kelly", None, "Eric", ""]

for i in str_list:
    if i=="":
        str_list.remove(i)
print("15th ans:",str_list)

#16 Remove special symbols / punctuation from a string

str1 = "/*Jon is @developer & musician"

sep="/$#%@&*(){}[]+=-"

rspecial=[]
for i in str1:
    rspecial.append(i)
for i in rspecial:
    if i in sep:
        rspecial.remove(i)
print("16th ans:",rspecial)

import string
str1 = "/*Jon is @developer & musician"
new_str = str1.translate(str.maketrans('', '',string.punctuation ))

#string.punctuation  is return special char and translate 3rd argument is for remove

print("16th ans:", new_str)


#17  Removal all characters from a string except integers
str1 = 'I am 25 years and 10 months old'
ans=[]
print("17th ans:")
for i in str1:
    ans.append(i)
for i in ans:
    if i.isdigit():
        print(i," ")

str1 = 'I am 25 years and 10 months old'

res = "".join([item for item in str1 if item.isdigit()])
print("second method :",res)
#18

str1 = "Emma25 is Data scientist50 and AI Expert"
res = []

temp = str1.split()

for item in temp:
    if any(char.isalpha() for char in item) and any(char.isdigit() for char in item):
        res.append(item)

for i in res:
    print(i)
#19 Replace each special symbol with # in the following string

str1 = '/*Jon is @developer & musician!!'
change=''
for i in str1:
    if i in string.punctuation:
        str1 = str1.replace(i, '#')
print(str1)

















