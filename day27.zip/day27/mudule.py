def  myModule(a,b):
	print(a+b)
	return