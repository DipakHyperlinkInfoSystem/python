from random import random

print("hello world")

str="hello world"

# 1
print("1 lenght of string :",len(str))

# 2
print("2 split the string",str.split('_'))

# 3
print("3 remove space afte split :",''.join(str.split()))

# 4
reverse = str[::-1]
print("4 reverse string :",reverse);

# 5
from collections import Counter

string= "dipak working on hyperlink"
cou = Counter(string)
cou1 = max(cou)
print("5 max use string word :",cou)

#6
words = str.split(' ')
print("6  word wise split and reverse :")

for x in words:

  print(x[::-1])

#7
print("7 replace the word:",str.replace("world","dipak"))


#8
a= "dipak"
b= "kavade"

print("8 word interchane: ")
st= a.replace(a,b);
print(st)
st1=b.replace(b,a);
print(st1)
# dipakkumar kumar=>bhai

st="dipakkumar"
re=st.replace("kumar","bhai")
#print(re)

def my_func():
    pass


my_func()


string = 'dipakkavade'
#abc = string.split()
# Define your variables
result = ''
for i in string:
        if i == 'd':
                i = 'a'
        result += i
print (result)



'''

# keyword

if(1==1 and 2==2):
  print("logic is right")

# as

  import calendar as c

  print(c.month_name[5])

for i in range(5):
  if i > 3:
    break
  print(i)
y = 1
x = 2
x += y
print(" value of x",x)


i = 0
while i <= 10:
    if i == 7:
        if i == 7:
            print("we got 7 in nested loop")
        i += 1
        continue
    print("The Number is  :" , i)
    i += 1
    print("loop if ")
print("loop terminet")

def check():
    print("dipak")

    def my_func():
        print('pass inside function')
    my_func()

check()

def sum(num):
    x=num+5
    if x > 10:
        print("x is freter than 10")
    else:
        print("x less than 10")

sum(10)


    def fibonaci(n):
        if n <= 1:
            return n
        else:
            return (fibonaci(n-1) +  fibonaci(n-2))
    10
    num = int(input("enter the number"))

    if num <=0:
        print("please enter greter than 0 ")

    else:
        print("fibonaci serise")
        for i in range(num):
            print(fibonaci(i))

'''


















