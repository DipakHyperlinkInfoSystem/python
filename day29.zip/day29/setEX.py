#1 Add a list of elements to a set
sample_set = {"Yellow", "Orange", "Black"}
sample_list = ["Blue", "Green", "Red"]

sample_set.update(sample_list)# set have update function to insert

print("1st ans: ",sample_set)

#2 Return a new set of identical items from two sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

ans=set1.intersection(set2)# intersection() return same value of both set

print("2 ans ",ans)

#3Get Only unique items from two sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
ans=set1.union(set2)
print("3",ans)

#4 Update the first set with items that don’t exist in the second set

set1 = {10, 20, 30}
set2 = {20, 40, 50}
set1.update(set2)
print("4",set1)

#5 Remove items from the set at once
set1 = {10, 20, 30, 40, 50}
set2={10,30,50}

set1.difference_update(set2) #Removes the items in this set that are also included in another, specified set
#set1.remove(set2)
print("5",set1)
#6 Return a set of elements present in Set A or B, but not both
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
set1.symmetric_difference(set2)
print("6",set1)

#7Check if two sets have any elements in common. If yes, display the common elements

if set2.isdisjoint(set1): # isdisjoint() return bool if thire two set have same item
    set2.intersection(set1)# intersection() retuen the same element from the set
print("7",set2)


#8Update set1 by adding items from set2, except common items

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1.update(set2)
print("8",set1)

#9 Remove items from set1 that are not common to both set1 and set2

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1.intersection_update(set2)
print("9",set1)


