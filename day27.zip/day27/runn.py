from  Dipak_pack import stand_1,stand_3,stand_2

stand_1.student1()

stand_2.student2()

stand_3.student3()

print("dipak")

for i in range(1, 11):
  print(i, end="")
'''
docstring
Python documentation strings (or docstrings) provide a convenient way of associating documentation with Python modules, functions, classes,
and methods.
What should a docstring look like?

1.The doc string line should begin with a capital letter and end with a period.
2.The first line should be a short description.
3.If there are more lines in the documentation string, the second line should be blank, visually separating the summary from the rest of the description.
4.The following lines should be one or more paragraphs describing the object’s calling conventions, its side effects, etc.

Declaring Docstrings:
	 The docstrings are declared using ”’triple single quotes”’ or “””triple double quotes””” just below the class, method or
	  function declaration. All functions should have a docstring.

Accessing Docstrings:
		 The docstrings can be accessed using the _doc_ method of the object or using the help function.

Eg.
def my_function():
    """Demonstrates triple double quotes
    docstrings and does nothing really."""
   
    return None
  
print("Using __doc__:")
print(my_function.__doc__)
op:Demonstrates triple double quotes
    docstrings and does nothing really.'''