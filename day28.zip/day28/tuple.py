# 1 Reverse the tuple
import rando
revers=(1,'man','woman','female','male','home','flat') #create a tuple

ans=revers[::-1] # for tuple revers

print("1st ans :",ans)

# 2 Access value 20 from the tuple

q2=(1,'man','woman','female','male','home','flat',1,'man','woman','female','male','home','flat',1,'man','woman','female','male','home','flat')

ans2=q2[20];

print("2nd ans :",ans2)

# 3 Create a tuple with single item 50

q3=(50,)
print("3rd ans :",type(q3))

# 4 Unpack the tuple into 4 variables
q4=("kajal","sharama","ahmedabad","gujarat")

(fname,lname,city,state)=q4 #for unpack tuple for into variable

print("4th ans : ",fname,lname,city,state)

# 5 Swap two tuples in Python
tup1=(1,2,3)
tup2=("a","b","c")
tup1,tup2 = tup2,tup1

print("5th ans tuple1:",tup1)
print("5th ans tuple2:",tup2)

# 6 Copy specific elements from one tuple to a new tuple

q6=("nirmal","jay","pavan")
a=q6
b=q6[0:4]
new_q6=("sejal",q6[1])

print("6th ans :")

print(b)#copy with different id address
print(id(q6))
print(id(a)) #its cpoy on dependende on q6
print(id(b))
print("of b",b)
print(new_q6)

# 7 Modify the tuple
q7=(1,2,"st","bus")
ans = list(q7) #convert tupel to list
ans[1]="4" # add elememnt into tuble
del ans[3] # delete form tuble
q7=tuple(ans)
print("7th ans :",q7)

# 8 Sort a tuple of tuples by 2nd item

q8=(6,0,5,7,4,3,8)

ans=sorted(q8[1::])
#ans[0]=q8[0]
ans=tuple(ans)
print("8th ans :",ans)

q=[("nirmal",4),("kavade",2),("sagar",3),("deep",1)]
q.sort(key=lambda x:x[1])
print(q)

# 9 Counts the number of occurrences of item 50 from a tuple

q9=(50,50,50,20,40,50)
print("9th ans :",q9.count(50))

# 10 Check if all items in the tuple are the same
q10 = ['Mon','Mon','Mon','Mon']
print("10th ans :")

ans = q10.count(q10[0]) == len(q10)
if (ans):

   print("All the elements are Equal")
else:
   print("Elements are not equal")

# 11 Test if tuple is distinct

q11=(0,3,1,4)
print((q11))
ans=set(q11)

if(len(set(ans))==len(ans)):
    print("its not distinct")
else:
    print("it is distinct")

# 12 Sort Tuples by Total digits
q12=[(1,4,3),(2,3,4,6)]

q12.sort(key=lambda x:x[0])

print(q12)

#12 Sort Tuples by Total digits

q12 = (3, 4, 6, 900), (1, 2), (12345,), (134, 234, 100)

# printing original list
print("The original list is : " + str(q12))

# performing sort, lambda function provides logic
res = sorted(q12, key=lambda x: sum([len(str(ele)) for ele in x]))

res1=tuple(res)
print("12th ans: ",res1)

#13 Sum of tuple elements

q13=(1,2,1)
ans=list(q13)
ans1=sum(ans)
print("13th ans :",ans1)

#14 Maximum and Minimum N elements in Tuple

q14=(10,12,6)
maxi=max(q14)
mani=min(q14)
print("14th ans :","max :",maxi,"mani:",mani)

#15 Find the size of a Tuple

q15=("dipak","number",1,2)
print("15th ans :",len(q15))







