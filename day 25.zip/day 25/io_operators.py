Python Input : 
input([prompt])
>>> num = input('Enter a number: ')
Enter a number: 10
>>> num
'10'



Python Import:
import math
print(math.pi)

>>> from math import pi
>>> pi
3.141592653589793


Operators:
1.Arithmetic operators : +,-,*,/,%,**(Exponentiation),//(Floor division)
2.Assignment operators : =,+=,-=,*=,/=,%=,//=,**=,&=,|=,^=,>>=,<<=
3.Comparison operators :==,!=,<,>,>=,<=
4.Logical operators : and,or,not
5.Identity operators : is,is not
6.Membership operators : in,not in
7.Bitwise operators :&,|,^(XOR),~(NOT),<<(Zero fill left shift),>>(Signed right shift)


*Arithmetic operators example

print(4+5)
print(10-5)
print(10*5)
print(100/2)
print(5**3) #work like 5*5*5
print(100//7) #return nearest round number

*Assignment operators

= assigne value to variable 

y=1,x=2
x = y + x
print(x);#3

x += y # work like x = x + y = 3

x -= y # work like x = x - y =-1

x *= y # work like x = x * Y = 2

x /= y # work like x = x / y = 0.5

x %= y # work like x = x % y = 1

x //= y # work for division and return nearest round number

x **= y # wrok like x = x ** y multiplication y number time of x

x &= y # 

x |= y # 

x ^= y # ''

x >>= y # This operator is used to perform Bitwise right shift on the operands and then assigning result to the left operand.

x <<= y # This operator is used to perform Bitwise left shift on the operands and then assigning result to the left operand.


* Comparison operators

x == y #Equal #false
x != y #Not equal	#True

x > y # greter than 
x < y # less than 

x >= y # 	Greater than or equal to

x <= y # Less than or equal to

* logical operators

print(true and true) # return true
x = 5

print(x > 3 and x < 10)

true


x = 5

print(x > 3 or x < 4)

true


x = 5

print(not(x > 3 and x < 10))

false

x = ["apple", "banana"]
y = ["apple", "banana"]
z = x

print(x is z) #true
print(x is y) #false
print(x == y) #true


*Membership operators

x = ["apple", "banana"]

print("banana" in x) #true



x = ["apple", "banana"]

print("pineapple" not in x) #true


*Bitwise operators

& 	AND	Sets each bit to 1 if both bits are 1
|	OR	Sets each bit to 1 if one of two bits is 1
 ^	XOR	Sets each bit to 1 if only one of two bits is 1
~ 	NOT	Inverts all the bits

<<	Zero fill left shift	Shift left by pushing zeros in from the right and let the leftmost bits fall off
>>	Signed right shift	Shift right by pushing copies of the leftmost bit in from the left, and let the rightmost bits fall off


* datatype 

Eg.str
x = "Hello World"
print(x)
print(type(x)) 

Eg.int
x = 20
print(x)
print(type(x)) 
op:20
<class 'int'>

Eg.float
x = 20.5
print(x)
print(type(x)) 

Eg.complex
x = 1j
print(x)
print(type(x)) 
op:1j
<class 'complex'>

Eg.list
x = ["apple", "banana", "cherry"]
print(x)
print(type(x)) 

Eg.tuple
x = ("apple", "banana", "cherry")
print(x)
print(type(x)) 

Eg.range
x = range(6)
print(x)
print(type(x)) 
op:range(0,6)
<class 'range'>

Eg.dict
x = {"name" : "John", "age" : 36}
print(x)
print(type(x)) 

Eg.set
x = {"apple", "banana", "cherry"}
print(x)
print(type(x)) 

Eg.frozenset
x = frozenset({"apple", "banana", "cherry"})
print(x)
print(type(x)) 

Eg.bool
x = True
print(x)
print(type(x)) 

Eg.bytes
x = b"Hello"
print(x)
print(type(x)) 
op:b'Hello'
<class 'bytes'>

Eg.bytearray
x = bytearray(5)
print(x)
print(type(x)) 
op:bytearray(b'\x00\x00\x00\x00\x00')
<class 'bytearray'>

Eg.memoryview
x = memoryview(bytes(5))
print(x)
print(type(x))
op:<memory at 0x01368FA0>
<class 'memoryview'> 

