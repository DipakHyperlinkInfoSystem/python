# 1 Reverse a list in Python

q1=[1,2,3]
ans=len(q1)
print("1st ans: ",ans)

# 2 Concatenate two lists index-wise
l1=[1,3,5]
l2=[5,6,8]
ans=l1+l2
print("2nd ans:",ans)

# 3 Turn every item of a list into its square

q3=[2,4,6]

print("3rd ans :")
for i in q3:
    i=i*i
    print(i)

#4 Iterate both lists simultaneously

l1=["dipak","sagar"]
l2=[1,2]

for i in l1:
    for j in l2:
        print(str(i)+str(j))

for a,b in zip(l1,l2):
    print("4th ans: ",a,b)

#5 Remove empty strings from the list of strings
q5=['','dipak']
while '' in q5:
    q5.remove('')
print("5th ans:",q5)

# 6 add new item to list after a specified item
q6=[1,2,3]

q6.insert(1,200)

print("6th ans :",q6)

#7 Extend nested list by adding the sublist

q7 = ["a", "b", ["c","l"], "m", "n"]
sub = ["k", "g", "j"]

q7[2].extend(sub)
print("7 ans: ",q7)

#8 Replace list’s item with new value if found

q8=[1,5,7,98,4]

print("8th ans:")
no=q8.index(1)
if no:
    q8[no] = 100

    print(q8)
else:
    print('not found')

#9 Remove all occurrences of a specific item from a list.

q9=[1,5,7,8]

if 5 in q9:
    q9.remove(5)
print("9th ans:",q9)





